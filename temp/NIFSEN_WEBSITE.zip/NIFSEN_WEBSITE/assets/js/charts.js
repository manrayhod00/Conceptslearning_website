﻿/**
 * Investor participation chart (India) — unique demat account holders.
 * Values from Govt. of India / Sansad annexure totals:
 * 2020: 3,88,87,353
 * 2021: 5,93,62,147
 * 2022: 7,69,40,514
 * 2023: 9,54,72,104
 * 2024 (up to Oct): 11,82,47,273
 */

function fmtCr(n){ return (n/1e7).toFixed(2); } // crore

function initInvestorChart(){
  const el = document.getElementById("investorChart");
  if(!el) return;
  if(typeof Chart === "undefined") return;

  const labels = ["2020","2021","2022","2023","2024 (Oct)"];
  const raw = [38887353,59362147,76940514,95472104,118247273];
  const dataCr = raw.map(v => +(v/1e7).toFixed(2));

  // Create chart only once
  if(el.__chart) return;

  const ctx = el.getContext("2d");

  // Build chart with subtle premium options
  const chart = new Chart(ctx, {
    type: "bar",
    data: {
      labels,
      datasets: [{
        label: "Unique demat account holders (crore)",
        data: dataCr,
        borderRadius: 14,
        borderSkipped: false
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      animation: { duration: 1200, easing: "easeOutQuart" },
      plugins: {
        legend: { display: false },
        tooltip: {
          callbacks: {
            label: (c) => ` ${c.raw} crore`
          }
        }
      },
      scales: {
        x: { grid: { display: false }, ticks: { font: { weight: "700" } } },
        y: {
          beginAtZero: true,
          ticks: { callback: (v)=> v + " cr" },
          grid: { color: "rgba(27,35,64,.08)" }
        }
      }
    }
  });

  // Theme colors (match your site: purple/orange)
  // We use two-tone gradient fill on bars.
  const g = ctx.createLinearGradient(0, 0, 0, el.height || 240);
  g.addColorStop(0, "rgba(59,43,214,.95)");   // purple
  g.addColorStop(1, "rgba(255,122,24,.92)");  // orange
  chart.data.datasets[0].backgroundColor = g;
  chart.update();

  el.__chart = chart;
}

// Animate only when chart is in view
(function(){
  const target = document.getElementById("investorChart");
  if(!target) return;

  const obs = new IntersectionObserver((entries) => {
    entries.forEach(e => {
      if(e.isIntersecting){
        initInvestorChart();
        obs.disconnect();
      }
    });
  }, { threshold: 0.25 });

  obs.observe(target);
})();
