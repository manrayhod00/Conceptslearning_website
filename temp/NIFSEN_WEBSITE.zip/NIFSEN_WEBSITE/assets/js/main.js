﻿/* ---- HTML partial includes (header/footer) ---- */
async function includePartials() {
  const nodes = document.querySelectorAll("[data-include]");
  for (const node of nodes) {
    const file = node.getAttribute("data-include");
    const res = await fetch(file);
    node.innerHTML = await res.text();
  }
}

/* ---- Drawer ---- */
function initDrawer(){
  const drawer = document.getElementById("drawer");
  const overlay = document.getElementById("drawerOverlay");
  const openBtn = document.getElementById("openDrawer");
  const closeBtn = document.getElementById("closeDrawer");

  if(!drawer || !overlay || !openBtn || !closeBtn) return;

  const open = () => {
    overlay.style.display = "block";
    drawer.style.transform = "translateX(0)";
    drawer.setAttribute("aria-hidden","false");
  };
  const close = () => {
    overlay.style.display = "none";
    drawer.style.transform = "translateX(110%)";
    drawer.setAttribute("aria-hidden","true");
  };

  openBtn.addEventListener("click", open);
  closeBtn.addEventListener("click", close);
  overlay.addEventListener("click", close);
}

/* ---- Investment comparison widget ---- */
function formatINRCompact(num){
  // num is rupees
  const abs = Math.abs(num);
  if(abs >= 10000000) return `₹ ${(num/10000000).toFixed(2)}Cr`;
  if(abs >= 100000) return `₹ ${(num/100000).toFixed(2)}L`;
  if(abs >= 1000) return `₹ ${(num/1000).toFixed(2)}K`;
  return `₹ ${Math.round(num)}`;
}

function futureValueMonthlySIP(pmt, years, annualRate){
  // FV = PMT * [((1+r)^n - 1)/r] * (1+r) ; assume deposit at period beginning (approx)
  const r = annualRate/12;
  const n = years*12;
  if(r === 0) return pmt*n;
  return pmt * (((Math.pow(1+r,n)-1)/r) * (1+r));
}

function initComparison(){
  const slider = document.getElementById("sipSlider");
  if(!slider) return;

  const amtEl = document.getElementById("sipAmount");
  const yearsEl = document.getElementById("sipYears");

  const bankEl = document.getElementById("bankFV");
  const fdEl = document.getElementById("fdFV");
  const goldEl = document.getElementById("goldFV");
  const sensexEl = document.getElementById("sensexFV");
  const mfEl = document.getElementById("mfFV");

  const YEARS = 25;
  if(yearsEl) yearsEl.textContent = YEARS;

  const calc = () => {
    const pmt = parseInt(slider.value,10);
    if(amtEl) amtEl.textContent = pmt.toLocaleString("en-IN");

    // Illustrative rates (you will later connect real data)
    const bank = futureValueMonthlySIP(pmt, YEARS, 0.03);
    const fd   = futureValueMonthlySIP(pmt, YEARS, 0.06);
    const gold = futureValueMonthlySIP(pmt, YEARS, 0.09);
    const sensex = futureValueMonthlySIP(pmt, YEARS, 0.11);
    const mf = futureValueMonthlySIP(pmt, YEARS, 0.15);

    if(bankEl) bankEl.textContent = formatINRCompact(bank);
    if(fdEl) fdEl.textContent = formatINRCompact(fd);
    if(goldEl) goldEl.textContent = formatINRCompact(gold);
    if(sensexEl) sensexEl.textContent = formatINRCompact(sensex);
    if(mfEl) mfEl.textContent = formatINRCompact(mf);
  };

  slider.addEventListener("input", calc);
  calc();
}

/* ---- Goals pills -> switch big card ---- */
function initGoals(){
  const big = document.getElementById("goalBig");
  const title = document.getElementById("goalTitle");
  const desc = document.getElementById("goalDesc");
  const link = document.getElementById("goalLink");
  const pills = document.querySelectorAll("[data-goal]");
  if(!big || pills.length === 0) return;

  const set = (p) => {
    const img = p.getAttribute("data-img");
    const t = p.getAttribute("data-title");
    const d = p.getAttribute("data-desc");
    const href = p.getAttribute("data-href");
    big.style.background = `url('${img}') center/cover no-repeat`;
    if(title) title.textContent = t;
    if(desc) desc.textContent = d;
    if(link) link.href = href;
  };

  pills.forEach(p => p.addEventListener("click", () => set(p)));
  set(pills[0]);
}

/* ---- Visitor counter (localStorage demo) ---- */
function initVisitor(){
  const el = document.getElementById("visitorCount");
  if(!el) return;

  const key = "nifsen_visits";
  const curr = parseInt(localStorage.getItem(key) || "0", 10) + 1;
  localStorage.setItem(key, String(curr));
  el.textContent = curr;
}

/* ---- Reveal + back to top ---- */
function initReveal(){
  const nodes = document.querySelectorAll(".reveal");
  const back = document.getElementById("backTop");

  const io = new IntersectionObserver((entries)=>{
    entries.forEach(e=>{
      if(e.isIntersecting) e.target.classList.add("show");
    });
  }, {threshold:0.12});

  nodes.forEach(n=>io.observe(n));

  const onScroll = () => {
    if(!back) return;
    back.style.display = (window.scrollY > 700) ? "grid" : "none";
  };
  window.addEventListener("scroll", onScroll);
  onScroll();

  if(back){
    back.addEventListener("click", ()=> window.scrollTo({top:0, behavior:"smooth"}));
  }
}

/* ---- boot ---- */
document.addEventListener("DOMContentLoaded", async () => {
  await includePartials();

  // after partials are injected:
  initDrawer();
  initComparison();
  initGoalsRail();
  initVisitor();
  initReveal();

  const y = document.getElementById("year");
  if(y) y.textContent = String(new Date().getFullYear());
});

/* ---- Premium Goals Rail: auto-flow + active tile ---- */
function initGoalsRail(){
  const big = document.getElementById("goalBig");
  const title = document.getElementById("goalTitle");
  const desc = document.getElementById("goalDesc");
  const link = document.getElementById("goalLink");

  const rail = document.getElementById("goalRail");
  const tiles = document.querySelectorAll(".goalTile");
  const prevBtn = document.getElementById("goalPrev");
  const nextBtn = document.getElementById("goalNext");

  if(!rail || tiles.length === 0 || !big) return;

  const setActive = (el) => {
    tiles.forEach(t => t.classList.remove("is-active"));
    el.classList.add("is-active");

    const img = el.getAttribute("data-img");
    const t = el.getAttribute("data-title");
    const d = el.getAttribute("data-desc");
    const href = el.getAttribute("data-href");

    big.classList.add("is-switching");
    big.style.background = `url('${img}') center/cover no-repeat`;
    if(title) title.textContent = t;
    if(desc) desc.textContent = d;
    if(link) link.href = href;

    setTimeout(()=> big.classList.remove("is-switching"), 260);

    // ensure tile is nicely positioned
    el.scrollIntoView({behavior:"smooth", inline:"center", block:"nearest"});
  };

  tiles.forEach(t => t.addEventListener("click", ()=> setActive(t)));
  setActive(tiles[0]);

  // Arrow scroll
  const scrollByOne = (dir) => {
    const w = tiles[0].getBoundingClientRect().width + 14;
    rail.scrollBy({left: dir*w*2, behavior:"smooth"});
  };
  if(prevBtn) prevBtn.addEventListener("click", ()=> scrollByOne(-1));
  if(nextBtn) nextBtn.addEventListener("click", ()=> scrollByOne(1));

  // Auto-flow (slow)
  let paused = false;
  let rafId = null;

  const tick = () => {
    if(!paused){
      rail.scrollLeft += 0.35; // premium slow glide
      // loop
      if(rail.scrollLeft >= (rail.scrollWidth - rail.clientWidth - 2)){
        rail.scrollLeft = 0;
      }
    }
    rafId = requestAnimationFrame(tick);
  };

  rail.addEventListener("mouseenter", ()=> paused = true);
  rail.addEventListener("mouseleave", ()=> paused = false);
  rail.addEventListener("touchstart", ()=> paused = true, {passive:true});
  rail.addEventListener("touchend", ()=> paused = false, {passive:true});

  rafId = requestAnimationFrame(tick);
}


